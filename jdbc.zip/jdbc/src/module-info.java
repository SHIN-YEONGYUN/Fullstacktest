/**
 * 
 */
/**
 * @author student
 *
 */
module jdbc {
	requires java.sql;
}