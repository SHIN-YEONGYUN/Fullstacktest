package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionTest {

	public static void main(String[] args) {
		Connection con = null;
		try {
		//jdbc driver 호출-mysql db
		//ClassNotFoundeXCEPTION
		Class.forName(DBInfo.driver);
		//mysql 연결
		//SQLException
		con = DriverManager.getConnection
				(DBInfo.url, DBInfo.account, DBInfo.password);
		
		System.out.println("연결성공");
		//sql
		con.close();//파일close,소켓close
		System.out.println("연결해제성공");
		}
		catch(ClassNotFoundException e) {
			System.out.println("드라이버 등록 여부를 확인하세요");
		}
		catch(SQLException e) {
			System.out.println("DB 연결 정보를 확인하세요");
		}finally {
			try {
				con.close();//파일close,소켓close
			}catch(SQLException e) {}
			System.out.println("연결해제성공");
		}
	}

}
