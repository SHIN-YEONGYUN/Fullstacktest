package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class InsertTest2 {

	public static void main(String[] args) {
		Connection con = null;
		try {
		//jdbc driver 호출-mysql db
		//ClassNotFoundeXCEPTION
		Class.forName(DBInfo.driver);
		//mysql 연결
		//SQLException
		con = DriverManager.getConnection
				(DBInfo.url, DBInfo.account, DBInfo.password);
		
		System.out.println("연결성공");
		
		// jdbc2  박자바 2222 010-3333-3333 lee@java.com now()
		String sql = "insert into c_member values(?,?,?,?,?,now())";
		PreparedStatement pt = con.prepareStatement(sql); //sql 저장 - db 전송 객체
		pt.setString (1,args[0]); // ID
		pt.setString (2,args[1]); // 이름 
		pt.setInt (3,Integer.parseInt(args[2])); // 암호 
		pt.setString (4,args[3]); // 폰
		pt.setString (5,args[4]); // 이메일 
		int rowcount = pt.executeUpdate();
		System.out.println("회원가입행 갯수 = " +rowcount);//1
		
		//con.close();//파일close,소켓close
		//System.out.println("연결해제성공");
		}
		catch(ClassNotFoundException e) {
			System.out.println("드라이버 등록 여부를 확인하세요");
		}
		catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				con.close();//파일close,소켓close
			}catch(SQLException e) {}
			System.out.println("연결해제성공");
		}
	}

}
