package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


class Emp{
	int id; // 사번
	String name; // 이름 
	double salary; // 급여
	int dept_id; // 부서코드
	String hire_date; // 입사일
	@Override
	public String toString() {
		return id + "-" + name + "-" + salary + "-" + dept_id + "-" + hire_date;
	}
	
}

class JDBCSelect{
	public ArrayList getEmp(String name) {
		ArrayList<Emp> list = new ArrayList();
		Connection con = null;
		Statement st = null;
		PreparedStatement pt = null;
		ResultSet rs = null;
		try {
		//jdbc driver 호출-mysql db
		//ClassNotFoundeXCEPTION
		Class.forName(DBInfo.driver);
		//mysql 연결
		//SQLException
		con = DriverManager.getConnection
				(DBInfo.url, DBInfo.account, DBInfo.password);
		
		System.out.println("연결성공");
		// william 사원보다 더 급여를 많이 받는 사원 이름 , 급여 조회

		String sql = "select employee_id, first_name f, salary, department_id, date_format(hire_date, '%Y년도%m월%d일') as hire_date from employees where salary >= all (select salary from employees where first_name=?)";
		pt = con.prepareStatement(sql);
		pt.setString(1,name);
		rs = pt.executeQuery();
		while(rs.next()) {
			Emp e = new Emp();
		    e.id = rs.getInt("employee_id");
			e.name = rs.getString("f");
			e.salary = rs.getDouble("salary");
			e.dept_id = rs.getInt("department_id");
			e.hire_date = rs.getString("hire_date");
			list.add(e);
		}
		
		//con.close();//파일close,소켓close
		//System.out.println("연결해제성공");
		}
		catch(ClassNotFoundException e) {
			System.out.println("드라이버 등록 여부를 확인하세요");
		}
		catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				rs.close();
				pt.close();
				con.close();//파일close,소켓close
				
				System.out.println(list.size());
				
				
			}catch(SQLException e) {}
			System.out.println("연결해제성공");
		}
		return list;
	}
}

public class SelectTest6 {

	public static void main(String[] args) {
		JDBCSelect jdbc = new JDBCSelect();
		ArrayList<Emp> list = jdbc.getEmp("william");
		for(Emp e : list) {
			System.out.println(e.toString());
		}

	}

}
