package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

public class SelectTest3 {

	public static void main(String[] args) {
		Connection con = null;
		try {
		//jdbc driver 호출-mysql db
		//ClassNotFoundeXCEPTION
		Class.forName(DBInfo.driver);
		//mysql 연결
		//SQLException
		con = DriverManager.getConnection
				(DBInfo.url, DBInfo.account, DBInfo.password);
		
		System.out.println("연결성공");
		// 급여총합. 1개 레코드

		String sql = "select sum(salary) as sums from emp_copy";
		PreparedStatement pt = con.prepareStatement(sql);
		ResultSet rs = pt.executeQuery();
		rs.next();
		System.out.println(rs.getDouble("sums"));
		// select insert update delete - rdbms 제공 표준 sql
		
		sql = "select * from emp_copy";
		pt = con.prepareStatement(sql);
		rs = pt.executeQuery();
		// rs 컬럼명, 컬럼타입, 컬럼갯수 조회
		ResultSetMetaData rsmd = rs.getMetaData();
		int col_cnt = rsmd.getColumnCount();
		for(int i = 1; i<= col_cnt; i++) {
			String col_name = rsmd.getColumnName(i);
			String type = rsmd.getColumnTypeName(i);
			System.out.println(i + "번째 컬럼 정보 = " + col_name + ":" + type);
		}
		/*while(rs.next()) {
			for(int i =1; i<=6; i++) {
				System.out.print(rs.getString(i) + ":");				
			}
			System.out.println();
		}*/
		
		
		/*while(rs.next()) {
			//int id = rs.getInt("employee_id");
			String name = rs.getString("first_name");
			Double salary = rs.getDouble("salary");
			int department_id = rs.getInt("department_id");
			//String hire_date = rs.getString("hire_date");
			System.out.printf
			("이름 : %s 급여 : %.2f 부서 : %d \n", name, salary, department_id);
		}*/
		
		//con.close();//파일close,소켓close
		//System.out.println("연결해제성공");
		}
		catch(ClassNotFoundException e) {
			System.out.println("드라이버 등록 여부를 확인하세요");
		}
		catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				con.close();//파일close,소켓close
			}catch(SQLException e) {}
			System.out.println("연결해제성공");
		}
	}

}
