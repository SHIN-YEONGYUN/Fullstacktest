package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class UpdateTest2 {

	public static void main(String[] args) {
		Connection con = null;
		try {

		Class.forName(DBInfo.driver);

		con = DriverManager.getConnection
				(DBInfo.url, DBInfo.account, DBInfo.password);
		
		System.out.println("연결성공");
		Scanner sc = new Scanner(System.in);
		
		System.out.println("수정할 사번 : ");
		int id = sc.nextInt();
		System.out.println("수정할 이름 : ");
		String name = sc.next();
		System.out.println("인상할 급여 : ");
		double salary = sc.nextDouble();

		// emp_copy 테이블 update
		// 키보드로
		/* 수정할 사번 : 100
		 * 수정할 이름 : xxx
		 * 인상할 급여 : 1000(현재급여 + 1000)
		 * 
		 */
		/* delete from emp_copy where */
		String sql = "update emp_copy set first_name=?, salary = salary+? where employee_id=?";
		PreparedStatement pt = con.prepareStatement(sql);
		pt.setString(1, name);
		pt.setDouble(2, salary);
		pt.setInt(3, id);
		int rowcount = pt.executeUpdate();
		System.out.println("수정행 = " + rowcount);

		}
		catch(ClassNotFoundException e) {
			System.out.println("드라이버 등록 여부를 확인하세요");
		}
		catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				con.close();//파일close,소켓close
			}catch(SQLException e) {}
			System.out.println("연결해제성공");
		}
	}

}
