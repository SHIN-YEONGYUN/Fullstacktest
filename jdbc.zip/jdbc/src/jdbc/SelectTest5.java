package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SelectTest5 {

	public static void main(String[] args) {
		Connection con = null;
		Statement st = null;
		PreparedStatement pt = null;
		ResultSet rs = null;
		try {
		//jdbc driver 호출-mysql db
		//ClassNotFoundeXCEPTION
		Class.forName(DBInfo.driver);
		//mysql 연결
		//SQLException
		con = DriverManager.getConnection
				(DBInfo.url, DBInfo.account, DBInfo.password);
		
		System.out.println("연결성공");
		// william 사원보다 더 급여를 많이 받는 사원 이름 , 급여 조회

		String sql = "select first_name f, salary from employees where salary >= any (select salary from employees where first_name=?)";
		pt = con.prepareStatement(sql);
		pt.setString(1,"William");
		rs = pt.executeQuery();
		while(rs.next()) {
			//int id = rs.getInt("employee_id");
			String name = rs.getString("f");
			Double salary = rs.getDouble("salary");
			//String hire_date = rs.getString("hire_date");
			System.out.printf
			("이름 : %s 급여 : %.2f \n", name, salary);
		}
		
		//con.close();//파일close,소켓close
		//System.out.println("연결해제성공");
		}
		catch(ClassNotFoundException e) {
			System.out.println("드라이버 등록 여부를 확인하세요");
		}
		catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				rs.close();
				pt.close();
				con.close();//파일close,소켓close
				System.out.println(rs.next());
			}catch(SQLException e) {}
			System.out.println("연결해제성공");
		}
	}

}
