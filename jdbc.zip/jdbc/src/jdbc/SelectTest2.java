package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SelectTest2 {

	public static void main(String[] args) {
		Connection con = null;
		try {
		//jdbc driver 호출-mysql db
		//ClassNotFoundeXCEPTION
		Class.forName(DBInfo.driver);
		//mysql 연결
		//SQLException
		con = DriverManager.getConnection
				(DBInfo.url, DBInfo.account, DBInfo.password);
		
		System.out.println("연결성공");
		// emp_copy 급여 5000 ~ 10000(포함)이면서 부서번호는 50번 사원이름,급여,부서코드 조회 

		String sql = "select first_name, salary, department_id from emp_copy where salary between ? and ? and department_id = ?";
		PreparedStatement pt = con.prepareStatement(sql);
		pt.setDouble(1, 5000);
		pt.setDouble(2, 10000);
		pt.setInt(3, 50);
		
		ResultSet rs = pt.executeQuery();
		while(rs.next()) {
			//int id = rs.getInt("employee_id");
			String name = rs.getString("first_name");
			Double salary = rs.getDouble("salary");
			int department_id = rs.getInt("department_id");
			//String hire_date = rs.getString("hire_date");
			System.out.printf
			("이름 : %s 급여 : %.2f 부서 : %d \n", name, salary, department_id);
		}
		
		//con.close();//파일close,소켓close
		//System.out.println("연결해제성공");
		}
		catch(ClassNotFoundException e) {
			System.out.println("드라이버 등록 여부를 확인하세요");
		}
		catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				con.close();//파일close,소켓close
			}catch(SQLException e) {}
			System.out.println("연결해제성공");
		}
	}

}
