package jdbc;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SelectTest {

	public static void main(String[] args) {
		Connection con = null;
		try {
		//jdbc driver 호출-mysql db
		//ClassNotFoundeXCEPTION
		Class.forName(DBInfo.driver);
		//mysql 연결
		//SQLException
		con = DriverManager.getConnection
				(DBInfo.url, DBInfo.account, DBInfo.password);
		
		System.out.println("연결성공");
		// emp_copy 모든 레코드의 모든 컬럼 조회
		

		// emp_copy 테이블 update
		// 키보드로
		/* 수정할 사번 : 100
		 * 수정할 이름 : xxx
		 * 인상할 급여 : 1000(현재급여 + 1000)
		 * 
		 */
		/* delete from emp_copy where */
		String sql = "select * from emp_copy";
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery(sql);
		while(rs.next()) {
			int id = rs.getInt("employee_id");
			String name = rs.getString("first_name");
			Double salary = rs.getDouble("salary");
			int department_id = rs.getInt("department_id");
			String hire_date = rs.getString("hire_date");
			System.out.printf
			("사번 : %d 이름 : %s 급여 : %f 부서 : %d 입사일 : %s \n", id, name, salary, department_id, hire_date);
		}
		
		//con.close();//파일close,소켓close
		//System.out.println("연결해제성공");
		}
		catch(ClassNotFoundException e) {
			System.out.println("드라이버 등록 여부를 확인하세요");
		}
		catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				con.close();//파일close,소켓close
			}catch(SQLException e) {}
			System.out.println("연결해제성공");
		}
	}

}
