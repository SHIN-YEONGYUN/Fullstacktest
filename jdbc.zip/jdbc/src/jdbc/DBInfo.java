package jdbc;

public class DBInfo {
	public static final String driver = "com.mysql.cj.jdbc.Driver";
	public static final String url = "jdbc:mysql://127.0.0.01:3306/empdb";	
	public static final String account = "emp";	
	public static final String password = "emp";		
}
