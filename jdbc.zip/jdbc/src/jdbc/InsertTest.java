package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class InsertTest {

	public static void main(String[] args) {
		Connection con = null;
		try {
		//jdbc driver 호출-mysql db
		//ClassNotFoundeXCEPTION
		Class.forName(DBInfo.driver);
		//mysql 연결
		//SQLException
		con = DriverManager.getConnection
				(DBInfo.url, DBInfo.account, DBInfo.password);
		
		System.out.println("연결성공");
		
		// jdbc1  이자바 1111 010-2222-2222 lee@java.com now()
		String sql = "insert into c_member values('" + args[0] +"', '" + args[1] + "', " + args[2] 
				+ " , '" + args[3] + "', '" + args[4] + "', now())";
		Statement st = con.createStatement(); //sql 저장 - db 전송 객체
		int rowcount = st.executeUpdate(sql);
		System.out.println("회원가입행 갯수 = " +rowcount);//1
		
		//con.close();//파일close,소켓close
		//System.out.println("연결해제성공");
		}
		catch(ClassNotFoundException e) {
			System.out.println("드라이버 등록 여부를 확인하세요");
		}
		catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				con.close();//파일close,소켓close
			}catch(SQLException e) {}
			System.out.println("연결해제성공");
		}
	}

}
