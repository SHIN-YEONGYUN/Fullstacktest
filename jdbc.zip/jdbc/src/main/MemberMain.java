package main;

import java.util.Scanner;

import view.MemberDeleteView;
import view.MemberInsertView;
import view.MemberSelectView;
import view.MemberSelectView2;
import view.MemberUpdateView;
import view.View;

//역할분담
public class MemberMain {

	public static void main(String[] args) {
		View view = null;
		while(true) {
			System.out.println("=== 회원 관리 프로그램을 시작합니다 ===");
			System.out.println("1. 회원가입");
			System.out.println("2. 회원정보 수정");
			System.out.println("3. 회원 탈퇴");
			System.out.println("4. 내정보 조회");
			System.out.println("5. 회원 리스트 조회"); // 아이디 이름 가입일 한 페이지당 3명씩
			System.out.println("6. 검색 조회");
			
			System.out.println("0. 종료");
			System.out.print("원하는 메뉴의 번호를 입력하세요 : ");
			Scanner sc = new Scanner(System.in);
			int menu = sc.nextInt();
			if(menu == 0) {
				System.exit(0);
			}else if(menu == 1) {
				view =  new MemberInsertView();
				view.input();
			}else if(menu == 2) {
				view =  new MemberUpdateView();
				view.input();	
				/* 1 >아이디 : xxxxx
				 * 수정항목 : 암호 | 이름 | 폰번호 | 이메일 
				 * 수정값 : 1111 | 변경이름 | ... 
				 * 
				 * 2> 아이디+암호 , 아이디+이름 , ....
				 * 3> MemberDTO 객체 생성(NAME, PHONE, EMAIL 없다)
				 * MemberDAO 의 int updateEmp(MemberDTO객체)  호출
				 * */

			}else if(menu == 3) {
				view = new MemberDeleteView();
				view.input();
				/* 아이디, 암호 입력 -
				 * MemberDAO int deleteMember(String memberid, String pw)
				 * 1. select pw from c_member where memberid=?
				 * 1-1. id, pw 일치 - delete from c_member where memberid=? 실행
				 * return 0;
				 * xxxView 출력 - "정상적으로 탈퇴 처리되었습니다."
				 * 1-2. id 일치, pw 불일치 - return 1 xxxxView 출력 "암호가 다릅니다. 탈퇴 불가"
				 * 1-3. id 없다 - return 2 xxxView 출력 "가입된 적이 없습니다." 
				 * */
			}
			else if(menu == 4) {
				view = new MemberSelectView();
				view.input();
				/* 아이디 , 암호 입력 --> MemberDTO 객체 선택적
				 * -->MemberDAO getMember(String id,String pw)
				 * 1> id, pw 맞으면 조회 모든 정보를 MemberDTO 객체  리턴
				 * --> 조회정보 출력 
				 * 2> ID 존재하고 PW 다르면 MemberDTO 객체 리턴 (아이디, 암호 X) 
				 * --> "암호가 일치하지 않습니다. 본인 정보 조회 불가" 출력
				 * 3> ID 존재하지 않으면 MemberDTO 객체 리턴 (아이디 X, 암호 X)
				 * -->"해당 아이디가 없습니다. 회원가입부터 진행해주세요." 출력
				 */
			}
			else if(menu == 5){
				view = new MemberSelectView2();
				view.input();
				/* MemberDAO dao = new MemberDAO();
				 * int getTotalMember(); 호출
				 * select count(*) from c_member; --> 5 -- 1 2
				 * 
				 * 사용 가능한 페이지는 다음과 같습니다.
				 * 1 2 3 4
				 * 
				 * 페이지번호 : 2
				 * ? getPaigingMember (int 페이징번호) 
				 * 가입일 최근 순서부터 3명씩 조회 
				 *
				 * 아이디 이름 가입일
				 * 아이디 이름 가입일
				 * 아이디 이름 가입일
				 * */
			}/*
			else if(menu == 6) {
				view = new MemberSelectView3();
				view.input();
			     검색어 : sql
			     * select * from c_ member where memberid lik '%sql%';
			     * or name like '%sql%';
			     * or email like '%sql%' 
			}*/
			/*	MemberSelectView-input
				아이디 : xxx
				암호 : xxx
				-- member 테이블 이미지 입력된 데이터들 
				중복 id, 암호 많다)
				테스트용 입력 id와 암호는 중복되지 않는 걸로 확인.
				
				MemberDAO - MemberDTO selectOneMember(String id, String password)
				1> MEMBER 테이블에서 ID, PASSWORD 같은 레코드 조회 ResulSet 결과를 --> MemberDTO 로 저장
				-- 출력
				   id가 member 존재하지 않으면 "회원가입부터 하세요." 출력
				   id  존재, 암호 다르면 "다시 입력하세요" 출력
				   
				
				*/
		}//while
		
	}//main

}

/*
 * 회원 관리 프로그램을 시작합니다
 * 1. 회원가입
 * 2. 회원정보 수정
 * 3. 회원 탈퇴
 * 4. 내정보 조회
 * 5. 회원 리스트 조회
 * 6. 종료
 * 원하는 메뉴의 번호를 입력하세요 : 
 *  
 *  */








