package view;

import java.util.ArrayList;
import java.util.Scanner;

import dao.MemberDAO;
import dto.MemberDTO;

public class MemberSelectView2 implements View {
	
    private int getTotalCount() {
		MemberDAO dao = new MemberDAO();
		return dao.getTotalMember();
	}

	@Override
	public void input() {
		int cntperpage =3;
		int total = getTotalCount();
		System.out.println("사용 가능한 페이지는 다음과 같습니다.");
		int totalpage =0;
		if(total % cntperpage == 0) {
			totalpage = total / cntperpage;
		} else {totalpage = total/cntperpage+1;}
		for(int i = 1; i<=totalpage; i++) {
			System.out.print(i + "  ");
		}
		System.out.println();
		
	    Scanner c = new Scanner(System.in);
	    System.out.println("페이지번호 입력 : ");
	    int pagenumber = c.nextInt();
	    
	    MemberDAO dao = new MemberDAO();
	    ArrayList<MemberDTO> list = dao.getPaigingMember(pagenumber, cntperpage);
	    for(MemberDTO dto : list) {
	    	System.out.println(dto.getMemberid() + " : " + dto.getName() + " : " + dto.getRegtime());
	    }

	}

}
