package view;

public interface View {
    void input();
}
