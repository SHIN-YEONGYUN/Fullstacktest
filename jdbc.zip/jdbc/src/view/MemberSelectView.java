package view;

import java.util.Scanner;

import dao.MemberDAO;
import dto.MemberDTO;

public class MemberSelectView implements View {

	@Override
	public void input() {
		Scanner c = new Scanner(System.in);
		System.out.println("아이디 입력 : ");
		String memberid = c.next();
		System.out.println("암호 입력 : ");
		int pw = c.nextInt();
		
	    MemberDAO dao = new MemberDAO();
	    MemberDTO dto = dao.getMember(memberid, pw);
	    if(dto.getMemberid() != null) {
	       if(dto.getPw() != 0) {
	    	   System.out.println(dto.toString());
	       }else {
	    	   System.out.println("암호가 다릅니다. 본인 정보 조회 불가");
	       }
	    }
	    else {
	    	System.out.println("해당 아이디가 없습니다. 회원가입부터 진행해주세요.");
	    }
		
	}

}














/* 아이디 , 암호 입력 --> MemberDTO 객체 선택적
 * -->MemberDAO getMember(String id,String pw)
 * 1> id, pw 맞으면 조회 모든 정보를 MemberDTO 객체  리턴
 * --> 조회정보 출력 
 * 2> ID 존재하고 PW 다르면 MemberDTO 객체 리턴 (아이디, 암호 X) 
 * --> "암호가 일치하지 않습니다. 본인 정보 조회 불가" 출력
 * 3> ID 존재하지 않으면 MemberDTO 객체 리턴 (아이디 X, 암호 X)
 * -->"해당 아이디가 없습니다. 회원가입부터 진행해주세요." 출력
 */