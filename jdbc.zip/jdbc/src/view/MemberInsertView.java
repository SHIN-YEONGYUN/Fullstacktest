package view;

import java.util.Scanner;

import dao.MemberDAO;
import dto.MemberDTO;

public class MemberInsertView implements View {

	@Override
	public void input() {
	// C_MEMBER  가입 저장 정보 아이디 암호 이름 폰 이메일 
		Scanner c = new Scanner(System.in);
		System.out.println("아이디 입력 : ");
		String memberid = c.next();
		System.out.println("암호 입력 : ");
		int pw = c.nextInt();
		System.out.println("이름 입력 : ");
		String name = c.next();
	    System.out.println("번호 입력 : ");
   	    String phone = c.next();
	    System.out.println("이메일 입력 : ");
     	String email = c.next();
     	// MEMBERDTO 객체 생성
     	MemberDTO dto = new MemberDTO();
     	dto.setMemberid(memberid);
     	dto.setName(name);;
     	dto.setPw(pw);
     	dto.setEmail(email);
     	dto.setPhone(phone);
     	MemberDAO dao = new MemberDAO();
     	dao.insertMember(dto);
     	System.out.println("회원가입 정상 처리되었습니다.");

	}

}
