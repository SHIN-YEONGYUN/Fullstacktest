package view;

import java.util.Scanner;

import dao.MemberDAO;
import dto.MemberDTO;

public class MemberUpdateView implements View {

	@Override
	public void input() {
		Scanner sc = new Scanner(System.in);
		System.out.println("아이디 입력 : ");
		String memberid = sc.next();
		System.out.println("수정항목 입력(암호 이름 번호 이메일 중 1개 입력) : ");
		String updateField = sc.next();
		System.out.println("수정값 : ");
		String updateValue = sc.next();
		
		MemberDTO dto = new MemberDTO();
		dto.setMemberid(memberid);
		if(updateField.equals("암호"))
		dto.setPw(Integer.parseInt(updateValue));
		else if(updateField.equals("이름"))
			dto.setName(updateValue);
		else if(updateField.equals("번호"))
			dto.setPhone(updateValue);
		else if(updateField.equals("이메일"))
			dto.setEmail(updateValue);
		MemberDAO dao = new MemberDAO();
		int updateResult = dao.updateMember(dto);
		System.out.println(updateResult + "행 변경");

	}

}
