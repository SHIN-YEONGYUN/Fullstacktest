package view;

import java.util.Scanner;

import dao.MemberDAO;
import dto.MemberDTO;

public class MemberDeleteView implements View {

	@Override
	public void input() {
	    Scanner c = new Scanner(System.in);
	    System.out.println("아이디 입력 : ");
	    String memberid = c.next();
	    System.out.println("암호 입력 : ");
	    int pw = c.nextInt();
	    
	    MemberDAO dao = new MemberDAO();
	    int result = dao.deleteMember(memberid, pw);
	    switch(result) {
	    case 0:
	    	System.out.println("정상적으로 탈퇴 처리되었습니다.");
	    	break;
	    case 1:
	    	System.out.println("암호가 다릅니다. 탈퇴 불가");
	    	break;
	    case 2:
	    	System.out.println("가입된 적이 없습니다.");
	    	break;
	    }

	}

}


/* 아이디, 암호 입력 -
 * MemberDAO int deleteMember(String memberid, String pw)
 * 1. select pw from c_member where memberid=?
 * 1-1. id, pw 일치 - delete from c_member where memberid=? 실행
 * return 0;
 * xxxView 출력 - "정상적으로 탈퇴 처리되었습니다."
 * 1-2. id 일치, pw 불일치 - return 1 xxxxView 출력 "암호가 다릅니다. 탈퇴 불가"
 * 1-3. id 없다 - return 2 xxxView 출력 "가입된 적이 없습니다." 
 * */