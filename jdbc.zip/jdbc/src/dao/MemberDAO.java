package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import dto.MemberDTO;
import jdbc.DBInfo;

public class MemberDAO {
	private int result;
	private Statement stmt;

	// 가입 메소드
	public void insertMember(MemberDTO dto) {

		Connection con = null;
		try {
		//jdbc driver 호출-mysql db
		//ClassNotFoundeXCEPTION
		Class.forName(DBInfo.driver);
		//mysql 연결
		//SQLException
		con = DriverManager.getConnection
				(DBInfo.url, DBInfo.account, DBInfo.password);
		
		// System.out.println("연결성공");
		
		// jdbc2  박자바 2222 010-3333-3333 lee@java.com now()
		String sql = "insert into c_member values(?,?,?,?,?,default)";
		PreparedStatement pt = con.prepareStatement(sql); //sql 저장 - db 전송 객체
		pt.setString (1,dto.getMemberid()); // ID
		pt.setString (2,dto.getName()); // 이름 
		pt.setInt (3,dto.getPw()); // 암호 
		pt.setString (4,dto.getPhone()); // 폰
		pt.setString (5,dto.getEmail()); // 이메일 
		
		int rowcount = pt.executeUpdate();
		// System.out.println("회원가입행 갯수 = " +rowcount);//1
		
		//con.close();//파일close,소켓close
		//System.out.println("연결해제성공");
		}
		catch(ClassNotFoundException e) {
			System.out.println("드라이버 등록 여부를 확인하세요");
		}
		catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				con.close();//파일close,소켓close
			}catch(SQLException e) {}
			System.out.println("연결해제성공");
		}
	}

	
	
	
	// 수정 메소드
		public int updateMember(MemberDTO dto) {
			Connection con = null;
			int result = 0;
			try {
			Class.forName(DBInfo.driver);
			con = DriverManager.getConnection
					(DBInfo.url, DBInfo.account, DBInfo.password);
			
			// System.out.println("연결성공");
			String colName = "";
			String colValue = "";
			if(dto.getPw() != 0) {
				colName = "pw";
				colValue = String.valueOf(dto.getPw());
			}
			else if(dto.getName() != null) {
				colName = "name";
				colValue = dto.getName();
			}
			else if(dto.getPhone() != null) {
				colName = "phone";
				colValue = dto.getPhone();
			}
			else if(dto.getEmail() != null) {
				colName = "email";
				colValue = dto.getEmail();
			}
			String sql = "update c_member set " + colName +"=? where memberid=?";
			PreparedStatement pt = con.prepareStatement(sql); //sql 저장 - db 전송 객체
			pt.setString (1,colValue);
			pt.setString (2,dto.getMemberid()); // ID 
	
			result = pt.executeUpdate();
			// System.out.println("회원가입행 갯수 = " +rowcount);//1
			}
			catch(ClassNotFoundException e) {
				System.out.println("드라이버 등록 여부를 확인하세요");
			}
			catch(SQLException e) {
				e.printStackTrace();
			}finally {
				try {
					con.close();//파일close,소켓close
				}catch(SQLException e) {}
				System.out.println("연결해제성공");
			}
			 return result;
		} //updateMember end

		// 내정보조회 메소드
		public MemberDTO getMember(String memberid,int pw) {
			MemberDTO dto = null;
			Connection con = null;
			try {
			Class.forName(DBInfo.driver);
			con = DriverManager.getConnection
					(DBInfo.url, DBInfo.account, DBInfo.password);
			
			// System.out.println("연결성공");
			
			// jdbc2  박자바 2222 010-3333-3333 lee@java.com now()
			String sql = "select memberid, name, pw, phone, email, date(regtime) from c_member where memberid=?";
			PreparedStatement pt = con.prepareStatement(sql); //sql 저장 - db 전송 객체
			pt.setString (1,memberid); // ID
			ResultSet rs = pt.executeQuery();
			if(rs.next()) {
				if(pw == rs.getInt("pw")) {
					dto = new MemberDTO(rs.getString("memberid"), rs.getString("name"), 
							rs.getInt("pw"), rs.getString("phone"),
							rs.getString("email"), rs.getString("date(regtime)")); // 2023-03-31 00:00:00
				}
				else { // 암호가 다르다
					dto = new MemberDTO();
					dto.setMemberid(memberid);			
					// dto.getMemberid() != null dto.getPw() --> 0
				}
			} // true / false
			else { // 해당 아이디 없다
			     dto = new MemberDTO(); // dto.getMemberid() --> null
			}
			// System.out.println("회원가입행 갯수 = " +rowcount);//1
			
			//con.close();//파일close,소켓close
			//System.out.println("연결해제성공");
			}
			catch(ClassNotFoundException e) {
				System.out.println("드라이버 등록 여부를 확인하세요");
			}
			catch(SQLException e) {
				e.printStackTrace();
			}finally {
				try {
					con.close();//파일close,소켓close
				}catch(SQLException e) {}
				System.out.println("연결해제성공");
			}
			return dto;
		} // getMember end

		// 회원탈퇴 메소드
		public int deleteMember(String memberid,int pw) {
			int result = 0;
			MemberDTO dto = null;
			Connection con = null;
			try {
			Class.forName(DBInfo.driver);
			con = DriverManager.getConnection
					(DBInfo.url, DBInfo.account, DBInfo.password);
			
			// System.out.println("연결성공");
			
			// jdbc2  박자바 2222 010-3333-3333 lee@java.com now()
			String sql = "select pw from c_member where memberid=?";
			PreparedStatement pt = con.prepareStatement(sql); //sql 저장 - db 전송 객체
			pt.setString (1,memberid); // ID
			ResultSet rs = pt.executeQuery();
			if(rs.next()) { // 삭제 아이디 존재
				if(pw == rs.getInt("pw")) {
					sql = "delete from c_member where memberid=?";
					pt = con.prepareStatement(sql); //sql 저장 - db 전송 객체
					pt.setString (1,memberid); // ID
					int row = pt.executeUpdate();
					if(row == 1) { result = 0;}
				}
				else { // 암호가 다르다
					result = 1;
				}
			} // true / false
			else { // 해당 아이디 없다
			     result = 2;
			}
			// System.out.println("회원가입행 갯수 = " +rowcount);//1
			
			//con.close();//파일close,소켓close
			//System.out.println("연결해제성공");
			}
			catch(ClassNotFoundException e) {
				System.out.println("드라이버 등록 여부를 확인하세요");
			}
			catch(SQLException e) {
				e.printStackTrace();
			}finally {
				try {
					con.close();//파일close,소켓close
				}catch(SQLException e) {}
				System.out.println("연결해제성공");
			}
			return result;
		} // deleteMember end
		
		
		// 회원수 조회 메소드
		public int getTotalMember() {
			int total = 0;
			Connection con = null;
			try {
			Class.forName(DBInfo.driver);
			con = DriverManager.getConnection
					(DBInfo.url, DBInfo.account, DBInfo.password);
			

			String sql = "select count(*) as cnt fro c_member";
			PreparedStatement pt = con.prepareStatement(sql); //sql 저장 - db 전송 객체
			ResultSet rs = pt.executeQuery();
			rs.next();
			total = rs.getInt("cnt");
			// System.out.println("회원가입행 갯수 = " +rowcount);//1
			
			//con.close();//파일close,소켓close
			//System.out.println("연결해제성공");
			}
			catch(ClassNotFoundException e) {
				System.out.println("드라이버 등록 여부를 확인하세요");
			}
			catch(SQLException e) {
				e.printStackTrace();
			}finally {
				try {
					con.close();//파일close,소켓close
				}catch(SQLException e) {}
				System.out.println("연결해제성공");
			}
			return total;
		} // getMember end

		// 페이지 처리된 회원리스트 메소드
		public ArrayList<MemberDTO> getPaigingMember(int pagenum, int cnt) {
			ArrayList<MemberDTO> list = new ArrayList();
			
			Connection con = null;
			try {
			Class.forName(DBInfo.driver);
			con = DriverManager.getConnection
					(DBInfo.url, DBInfo.account, DBInfo.password);
			

			String sql = "select memberid, name, regtime from c_member order by regtime desc limit ?,?";
			PreparedStatement pt = con.prepareStatement(sql); //sql 저장 - db 전송 객체
			pt.setInt(1, (pagenum-1)*cnt);
			pt.setInt(2, cnt);
			ResultSet rs = pt.executeQuery();
			while(rs.next()) {
				MemberDTO dto = new MemberDTO();
				dto.setMemberid(rs.getString("memberid"));
				dto.setName(rs.getString("name"));
				dto.setRegtime(rs.getString("regtime"));
				list.add(dto);
			}
			}
			catch(ClassNotFoundException e) {
				System.out.println("드라이버 등록 여부를 확인하세요");
			}
			catch(SQLException e) {
				e.printStackTrace();
			}finally {
				try {
					con.close();//파일close,소켓close
				}catch(SQLException e) {}
				System.out.println("연결해제성공");
			}
			return list;
		} // getMember end

		
} // class end
