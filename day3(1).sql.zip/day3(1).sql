# wherer group by having order by
# 사원이름 부서이름 조회하되 부서코드가 50, 80, 100 부서만 해당.

select e.first_name, e.department_id, d.department_name
from employees e inner join departments d on e.department_id=d.department_id
where e.department_id in ( 50 , 80, 100);

# 부서이름 부서이름별급여평균 
select avg(salary) from employees;-- 1행 리턴. 다른 컬럼 동시 조회 불가
select department_name, avg(salary) 
from employees e inner join departments d on e.department_id=d.department_id
group by department_name
having avg(salary) >= 10000
order by 2 desc;

# 사원이름 부서이름 도시이름 국가이름
desc locations;
desc countries;

select first_name, departMent_name, city, couNtry_name
from employees e 
INNER JOIN departments d on e.dePARTMENT_ID=D.DEPARTMENT_ID
INNER JOIN LOCATIONS L on D.LOCATION_ID=L.LOCATION_ID
INNER JOIN COUNTRIES C on L.COUNTRY_ID=C.COUNTRY_ID;

# inner <--> outer join
# 조인에 참여 모든 테이블에 공통 존재 데이터만 조회= 범위 만족 조회

# 106개
select e.first_name, e.department_id, d.department_name
from employees e join departments d on e.department_id=d.department_id; 

select found_rows();

select count(*), count(department_id) from employees;
select * from employees where department_id is null;

# 107개 emplolyees 존재 모든 레코드 조인 
select e.first_name, e.department_id, d.department_name
from employees e LEFT OUTER join departments d on e.department_id=d.department_id; 

select e.first_name, e.department_id, d.department_name
from departments d  RIGHT OUTER join employees e   on e.department_id=d.department_id;

select found_rows();

# 부서이름 부서장이름 조회하되 부서장 없는 부서도 포함 조회
SELECT department_name, ifnull(first_name, '부서장없음') 부서장이름
FROM employees e right outer join departments d on d.manager_id=e.employee_id;-- 27개

select * from departments;-- 27개
select * from departments where manager_id is null;-- 16

# full outer join - mysql 미지원, rdbms 표준 명시.

#cross join - t1 join t2 ; on 뒤 생략 ; 지양

# self join
# 사원이름 사원급여 상사이름 상사급여 조회하되 사원급여가 상사의 급여보다 많은 경우에만 조회
select emp.first_name 내이름, emp.salary 내급여,  manager.first_name '상사 이름', manager.salary '상사 급여'
from employees emp join employees manager on emp.manager_id =  manager.employee_id
where emp.salary > manager.salary;


select emp.first_name 내이름, emp.salary 내급여,  manager.first_name '상사 이름', manager.salary '상사 급여'
from employees emp join employees manager on emp.manager_id =  manager.employee_id;

select * from employees where manager_id is null;

select emp.first_name 내이름, emp.salary 내급여,  ifnull(manager.first_name,'사장') '상사 이름', 
ifnull(manager.salary, '보안') '상사 급여'
from employees emp left join employees manager on emp.manager_id =  manager.employee_id;

# subquery
/*(create table a (select * from b);--  테이블 생성+ 데이터 복사
insert into a select * from b; -- 테이블 이미지 존재+ 데이터 복사
update a
set 컬럼 = (select * from (select 컬럼명2 from a where .... ) as 별칭)
where*/

/*
select (select..)
from (select )
where (select)
*/

# KELLY 사원 모든 정보 조회
SELECT * FROM EMPLOYEES WHERE FIRST_NAME='kelly';
# KELLY 사원 부서 정보 조회
 SELECT department FROM EMPLOYEES WHERE FIRST_NAME='kelly';

# kelly와 같은 부서 근무 부서원 이름, 부서코드 조회
select first_name, department_id
from employees
where department_id=(SELECT department_id FROM EMPLOYEES WHERE FIRST_NAME='kelly')
and first_name != 'kelly';

# peter와 같은 부서 근무 부서원 이름, 부서코드 조회
 SELECT department_id FROM EMPLOYEES WHERE FIRST_NAME='peter';
 
select first_name, department_id
from employees
where department_id in (SELECT department_id FROM EMPLOYEES WHERE FIRST_NAME='peter');


# in-다중행 연산자 , = 단일행 연산자


select first_name, department_id, job_id
from employees
where (department_id, job_id) =(SELECT department_id, job_id FROM EMPLOYEES WHERE FIRST_NAME='kelly')
and first_name != 'kelly';

# kelley 보다 급여를 더 많은 사원 조회
SELECT salary FROM EMPLOYEES WHERE FIRST_NAME='kelly';

select first_name, salary
from employees
where salary > (SELECT salary FROM EMPLOYEES WHERE FIRST_NAME='kelly');

# adam 보다 급여를 더 많은 사원 조회
SELECT salary FROM EMPLOYEES WHERE FIRST_NAME='peter';-- 2500 100000 9000

select first_name, salary
from employees
where salary > any (SELECT salary FROM EMPLOYEES WHERE FIRST_NAME='peter'); -- 최소값보다 크면 된다

select first_name, salary
from employees
where salary > all (SELECT salary FROM EMPLOYEES WHERE FIRST_NAME='peter');-- 최대값보다 커야 한다

/*단일행 subquery  - '=' "<" ">"
 다중행 subquery - in  / =any =all  > any > all 
*/


# scalar subquery - select 절 내부 select. 1개행 리턴
select salary 내급여, (select avg(salary) from employees) 평균급여 from employees;

select first_name, salary, (SELECT salary FROM EMPLOYEES WHERE FIRST_NAME='kelly')
from employees
where salary > (SELECT salary FROM EMPLOYEES WHERE FIRST_NAME='kelly');


# inline view - from절 내부 subquery 
select salaryinfo.max, min, sum, avg_sal, cnt
from (select max(salary) as max , min(salary) min, sum(salary) sum, avg(salary) avg_sal, count(salary) cnt
from employees) as salaryinfo ;

# mysql -  limit 절 0, 3  말고 오라클 - 페이징처리

-- join query(여러 테이블 '컬럼' 결합-->레코드1개) , subquery
-- union
 
# 50번 부서원 별도 테이블 생성 / job_id '%MAN%' 직종 종사 테이블 생성
DROP TABLE IF EXISTS EMP_DEPT50;
CREATE TABLE EMP_DEPT_50 (SELECT * FROM EMPLOYEES WHERE DEPARTMENT_ID=50);
CREATE TABLE EMP_JOB_MAN (SELECT * FROM EMPLOYEES WHERE JOB_ID LIKE '%MAN%');

SELECT * FROM EMP_DEPT_50; -- 45
SELECT * FROM EMP_JOB_MAN; -- 12

# 재난지원금 지원한다. 대상은 50번 부서와 MANAGER 직종이다.(중복 허용X)
SELECT EMPLOYEE_ID, FIRST_NAME, DEPARTMENT_ID, JOB_ID FROM EMP_DEPT_50
UNION
SELECT EMPLOYEE_ID, FIRST_NAME, DEPARTMENT_ID, JOB_ID FROM EMP_JOB_MAN;-- 52(5명 중복)

# 재난지원금 지원한다. 대상은 50번 부서와 MANAGER 직종이다.(중복 허용O)
SELECT EMPLOYEE_ID, FIRST_NAME, DEPARTMENT_ID, JOB_ID FROM EMP_DEPT_50
UNION ALL
SELECT EMPLOYEE_ID, FIRST_NAME, DEPARTMENT_ID, JOB_ID FROM EMP_JOB_MAN;-- 57

# IN / NOT IN / EXISTS / NOT EXISTS

# 모든 WILLIAM (여러명) 부서와 같은 부서원 이름 부서코드 조회
SELECT FIRST_NAME, DEPARTMENT_ID
FROM EMPLOYEES
WHERE DEPARTMENT_ID IN (SELECT DEPARTMENT_ID FROM EMPLOYEES WHERE FIRST_NAME='WILLIAM'); 
-- subquery 먼저 진행/main 


# 모든 WILLIAM (여러명) 부서와 같은 부서원 이름 부서코드 조회
SELECT FIRST_NAME, DEPARTMENT_ID
FROM EMPLOYEES outertbl 
WHERE  exists 
(SELECT DEPARTMENT_ID FROM EMPLOYEES innertbl 
WHERE FIRST_NAME='WILLIAM' and innertbl.department_id= outertbl.DEPARTMENT_ID ); 
-- main 레코드 1개 우선  진행 / subquery




# 모든 WILLIAM 부서와 다른 부서원의 이름 부서코드 조회
SELECT FIRST_NAME, DEPARTMENT_ID
FROM EMPLOYEES
WHERE DEPARTMENT_ID not IN (SELECT DEPARTMENT_ID FROM EMPLOYEES WHERE FIRST_NAME='WILLIAM');

/*
sql
조건함수  case
set 
----------------------------
변수선언
조건
sql 반복
-----------------------------
*/

# DDL - DATA DEFINITION LANGUAGE
# CREATE TABLE 
# ALTER 
# DROP

select version();

/*
member 테이블 생성
아이디 VARCHAR(20)
이름 VARCHAR(10)
암호 INT
폰번호 CHAR(13)
이메일 VARCHAR(30)
가입일 DATETIME

*/

CREATE TABLE MEMBER
(MEMBERID VARCHAR(20) , 
NAME VARCHAR(10),
PW INT,
PHONE CHAR(13),
EMAIL VARCHAR(30),
REGTIME DATETIME);

DESC MEMBER;

INSERT INTO MEMBER VALUES('ID1', '홍길동',1111 ,'010-1234-5678', 'HONG@mul.com', '2023-03-29 14:06:10');
INSERT INTO MEMBER VALUES('ID2', '박길동',2222 ,'010-5678-1234', 'park@mul.com', now());
INSERT INTO MEMBER VALUES('ID3', '우재남',3333 ,'010-8888-1234', 'wook@camp.com', curdate());

select @@autocommit;-- 1 ( 자동 dml commit-rollback 취소불가) 
/* set autocommit = false;  
select @@autocommit;-- 0 ( 선택적 dml commit,rollback  가능) 
 */

select * from member;

-- 폰번호 뒷자리 1234인 회원의 이름, 암호(11--), 폰번호 조회. 
select name, insert(pw, 3, char_length(pw)-2, repeat('-', char_length(pw)-2)) 암호, phone
from member
where phone like '%1234';

#address varchar(50) 컬럼 추가
alter table member add address varchar(10);
desc member;
select * from member;
INSERT INTO MEMBER VALUES('ID4', '우재남',3333 ,'010-8888-1234', 'wook@camp.com', curdate(),'서울시 강남구');
select * from member;

# 기존 컬럼 길이수정
alter table member modify address varchar(50);

# 기존 컬럼 타입수정
alter table member modify address int;

# 기존 컬럼 이름수정
alter table member change address addr varchar(50);
desc member;
# 기존 컬럼 삭제
alter table member drop addr;
desc member;

-- drop table member;
-- drop table if exists member;

select * from member;

# 데이터 무결성 보장 - 데이터 규칙 - 제약조건 constraint
/*
c_member 테이블 생성
아이디 VARCHAR(20) not null + unique
이름 VARCHAR(10) not null
암호 INT
폰번호 CHAR(13) unique
이메일 VARCHAR(30) ',,@,,,,,'
가입일 DATETIME 현재시각기본값
*/
create table c_member
(memberid varchar(20) primary key , 
name varchar(10) not null,
pw int,
phone char(13) unique, 
email varchar(30) check (email like '%@%'),
regtime datetime default now()
);

desc c_member;

-- 제약조건 효력은  dml 실행시. 제약조건 정의는 ddl 실행시
insert into c_member values('id1','홍길동',1111,'010-1234-5678', "hong@mul.com", default);
insert into c_member values('id2','박길동',2222,'010-4321-5678', "park/mul.com", default);-- error
insert into c_member values('id2','박길동',2222,'010-4321-5678', "park@mul.com", default);-- ok
insert into c_member values('id3','우재남',3333, '010-5678-1111', "woo@mul.com", default);-- ok
insert into c_member values('id4','남궁성',4444 ,'010-4321-2222', "nam@mul.com", curdate());-- ok
-- c_member_chk_1 
-- 제약조건 이름 확인(이름부여/시스템자동부여)

-- information_schema

use information_schema;
show tables; -- table_constraints 테이블
desc table_constraints; -- 컬럼정보

select * from table_constraints where table_name='c_member';
select database(), version();


# c_memo
/*c_memo 테이블 생성
메모코드 int primary key auto_Increment
제목 VARCHAR(50) not null
내용 varchar(4000)
폰번호 CHAR(13) unique
메모작성시간 writingtime datetime 
작성자 varchar(20) c_member테이블 존재 memberid만 
*/

create table c_memo
(
memoid int primary key  auto_increment,
title varchar(50) not null,
contents varchar(4000) ,
writingtime datetime default now(),
writer varchar(20)
);
-- c_member테이블 먼저 생성 조건 선행

-- 제약조건 추가
-- alter table c_member add constraint  / modify con... / drop con...

alter table c_memo add constraint foreign key (writer) references c_member(memberid);
select * from information_schema.table_constraints where table_name='c_memo';

alter table c_memo  drop foreign key c_memo_ibfk_1;
select * from information_schema.table_constraints where table_name='c_memo';

-- foreign key 아닐 때
alter table c_memo  drop constraint 제약조건명;
-- -- foreign key  때
alter table c_memo  drop foreign key 외래키제약조건명;


insert into c_memo values(null, '1번글제목','1번글내용입니다', default, 'id1');-- ok
insert into c_memo(title, writer) values('2번글제목','id1');-- ok auto_increment, default 컬럼이름 없으면  
insert into c_memo values(null, '3번글제목','3번글내용입니다', default, 'id5');-- error fk
insert into c_memo values(null, '3번글제목','3번글내용입니다', default, 'id2');-- ok
select * from c_memo;

# id2 회원 탈퇴(c_member-부모, c_memo)-
delete from  c_memo where writer ='id2';
delete from c_member where memberid='id2'; -- 오류

# 부모 삭제시 자동 자식 삭제, 부모 변경시 자동 자식 변경 옵션 외래키 삭제-추가
alter table c_memo  drop foreign key c_memo_ibfk_1;
alter table c_memo add constraint foreign key (writer) references c_member(memberid) 
on delete cascade on update cascade;

delete from c_member where memberid='id2'; -- ok 
select * from c_memo where writer='id2';-- 자식자동삭제
select * from c_member where memberid='id2';-- 부ㅠ모

select * from information_schema.table_constraints where table_name='c_memo';
select * from information_schema.table_constraints where table_name='c_member';

-- 제약조건
-- 테이블 생성 제약조건
create table a (b int primary key / not null / unique) PIRMARY/UNIQUE이름
create table a (b int check (email like '%@%')) 테이블명_CHK_X

ALTER TABLE C_MEMO DROP FOREIGN KEY 외래키이름; 테이블명_IBFK_X

ALTER TABLE C_MEMO ADD CONSTRAINT 사용자제약조건이름 FOREIGN KEY(컬럼명) REFERENCES 부모(부모컬럼);

ALTER TABLE C_MEMO ADD CONSTRAINT 사용자제약조건이름 PRIMARY KEY(컬럼명) ;
ALTER TABLE C_MEMO ADD CONSTRAINT 사용자제약조건이름 CHECK(컬럼명) (....) ;
ALTER TABLE C_MEMO MODIFY CONSTRAINT 사용자제약조건이름 NOT NULL(컬럼명);


/* ROOT
create datebase db명;
create user 이름@'%' identified by '암호'; ddl
grant all privileges on db명.* to 이름@'%'; dcl
grant select on db.* to 이름@'%';
 이름 접속
 use db명
 commit / rollback - tcl+dml
 
*/

목 - 자바 + sql  
금 - 2시간 20문제 + 과제2개 제출
