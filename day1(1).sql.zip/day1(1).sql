
 #show databases;
 /*USE empdb;*/
 -- show tables;
-- desc 테이블명;
 
select * from countries;
desc countries;
select country_name from countries;
select employee_id, first_name, last_name, salary, job_id from employees;
desc employees;

-- 컬럼명 수정x.  조회 임시 사번, 이름, 성, 급여, 직종 alias 
select employee_id '사원 번호' , first_name 이름, last_name 성, salary 급여, job_id 직종 
from employees;
desc employees; 
SELECT salary*12 연봉 FROM employees; -- %(자바연산자-나머지 없다) , String/char,varchar(db '+'문자열결합x) +-*/

-- 급여 (salary)10000 이상이고 15000 미만  사원의 사번, 급여, 이름 컬럼 조회
select employee_id '사번' , first_name 이름, salary 급여
from employees
where salary >= 10000 and salary <= 15000; -- &&-and , ||-or 

-- 범위 연산자 between ? and ?
select employee_id '사번' , first_name 이름, salary 급여
from employees
where salary between 10000 and 15000; -- &&-and , ||-or
 
 
 
--  사번 100, 200, 300, 100개  사원의 사번, 급여, 이름 컬럼 조회
select employee_id '사번' , first_name 이름, salary 급여
from employees
where employee_id = 100 or employee_id=200 or employee_id=300;

-- 목록 연산자 - in (값1, ..)
select employee_id '사번' , first_name 이름, salary 급여
from employees
where employee_id in (100 , 200, 300, 400, 500);


-- first_name에서 'KE'로 시작하는 사원의 이름 조회
-- 유사패턴 비교 연산자  LIKE %(모든문자 (0개이상)갯수 무관), _(모든 문자 1개)
SELECT FIRST_NAME
FROM EMPLOYEES
WHERE first_name LIKE 'KE%';

-- first_name에서 'K'로 시작하고 이름 문자갯수가 5개인 사원의 이름 조회
SELECT FIRST_NAME
FROM EMPLOYEES
WHERE first_name LIKE 'K____';

-- last_name에서 'ng'로 끝나는 이름의 사원의 성, 이름 조회
SELECT FIRST_NAME, last_name
FROM EMPLOYEES
WHERE last_name LIKE '%ng';

-- last_name에서 'er' 포함하는 이름의 사원의 성, 이름 조회
SELECT FIRST_NAME, last_name
FROM EMPLOYEES
where last_name like '%er%';

-- 정수, 실수,  문자열('', "") , 날짜시간('', "")
--  bigint/smallint/int/decimal(5,0)  float/double/decimal(8,2)  char(10)/varchar(10)  date/time/datetime

desc employees; -- windows / + ..... 

-- 커미션 컬럼 조회
select commission_pct from employees;

-- 이름, 입사일 조회
-- 날짜시간('', "")-문자열(길이, 양식 한정) 

select first_name, hire_date 
from employees;

-- 7장함수 가운데 현재시각 함수 1개 결과 레코드 보여줄 수 있는 가상의 내장된 테이블 dual;
-- 연도4자리-월2자리-일2자리 시간2자리:분2자리:초2자리
select now() /*from dual*/;

-- 2006년도,2007,2008년도 이후(2006-01-01 00:00:00) ~  입사 사원의 이름, 입사일 조회
select first_name, hire_date 
from employees
where hire_date >= '2006-01-01 00:00:00';

select first_name, hire_date 
from employees
where hire_date like '2006%' or hire_date like '2007%' or hire_date like '2008%';


-- 2006년도 (2006-01-01 00:00:00) ~ (2006-12-31 23:59:59) 입사 사원의 이름, 입사일 조회
select first_name, hire_date 
from employees
where hire_date >= '2006-01-01 00:00:00' 
and hire_date <= '2006-12-31 23:59:59'  ;

select first_name, hire_date 
from employees
where hire_date like '2006%'  ;

-- 6월 입사자 사원의 이름, 입사일 조회 4자리-2자리월 
select first_name, hire_date 
from employees
where hire_date like '_____06%'  ;

-- commission_pct null - 커미션 못받는다
-- null처리 연산자 is null, is not null  
select first_name, commission_pct from employees
where commission_pct is not null; 

-- 사원별 직종코드('IT_PROG') 조회
select FIRST_NAME, job_id from employees;

-- 직종종류만 조회
select distinct JOB_ID from employees;

-- FIRST_NAME, LAST_NAME  2개 컬럼 저장 상태
-- 조회시 성은 XXX 이고 이름은 XXX  입니다 출력
-- 오라클 '||', MYSQL CONCAT
SELECT concat( "성은 " , last_name , "이고 이름은 " , first_name ," 입니다") 사원정보
FROM EMPLOYEEs;

/* 테이블명,컬럼명 규칙 
1. mysql 64문자까지
2. 일반문자 숫자, _, $ 사용
3. 숫자시작불가능
4. 예약어 불가능
5. 의미있는 이름
*/

-- 사번 순서로 정렬 조회
select employee_id from employees order by employee_id;
select employee_id from employees order by first_name; -- 실행ok. 무의미.
select employee_id from employees order by 1; 
select employee_id 사번 from employees order by 사번; 

-- 급여 많이 받는 사원부터 정렬 조회
select first_name,salary
from employees
order by salary desc  , first_name;


-- 커미션 받는 사원 조회. 커미션 적은 사원부터 조회(오름차순정렬시 null 먼저 정렬 / null 나중 정렬)
select commission_pct , first_name
from employees
-- where commission_pct is not null
order by 1 desc /*nulls first*/;

-- 조회 데이터 10 개 
set @var1 = 1;
set @var2 = (@var1 -1)*10; 
select @var1 , @var2;
select * from employees where employee_id=@var1;

-- select * from employees order by employee_id limit @var2, 10; -- 0번인덱스부터 10개

-- employees 테이블 복사 emp_copy 테이블-subquery 사용한 테이블 복사
create table emp_copy 
(select first_name name , employee_id id, salary, department_id dept_id, hire_date 
from employees where salary >= 5000);  
-- ???개 * 4컬럼
select * from emp_copy;


set @var1 = 1; -- 1.변수 연결 정의
PREPARE myQuery
  FROM 'select * from employees order by employee_id limit ?, 10';-- 2.sql 정의
EXECUTE myQuery USING @var1; -- 3.실행

-- 그룹함수
select max(salary) from employees ; -- 107 중
select max(salary) from employees where salary < 10000; 
/*실행순서 
1. from 테이블 가져온다 (107)
2. where 실행 (갯수 줄어든다)
3. select 컬럼명, 함수 실행
4. order by 
*/
select max(salary), min(salary), sum(salary), avg(salary), count(salary) from employees ; 
select max(first_name), min(first_name), sum(first_name) from employees ; 
select max(hire_date) 최근입사일 , min(hire_date) 최초입사일 from employees ;
select count(department_id) , count(commission_Pct), count(*) from employees ;

select * from employees where department_id is null;

select count(*) 총사원수 , employee_id 사번 FROM EMPLOYEES;
--      107(1개레코드)   ,    107개레코드

-- 전체 사원의 급여 총합 조회
select sum(salary) from employees;

-- 50번 부서원 급여 총합 조회
select sum(salary) from employees where department_id = 50; 

-- 부서별(10-10, 20-3, ...... )로 급여 총합 조회
select  department_id 부서코드, sum(salary) 부서별총합 
from employees
where department_id is not null
group by department_id
order by 2 desc;


-- 부서별 직종코드별 
-- 10 IT_PROG  XXX
-- 50 NET_MAN  XXXX
-- 10  NET_MAN XXX

-- 10번 부서의 부분합 XXXX
--  20              XX
 -- JOIN , UNION , ROLLUP

select  department_id 부서코드, JOB_ID 직종코드, sum(salary) 부서별직종별총합 
from employees
group by department_id, JOB_ID
order by 3 desc;





-- 부서별(10-10, 20-3, ...... )로 급여 총합 조회
select  department_id 부서코드, sum(salary) 부서별총합 
from employees
where department_id is not null
group by department_id
HAVING sum(salary) >=50000
order by 2 desc;
-- FROM -> WHERE ->GROUP BY ->HAVING -> SELECT _>ORDER BY


-- ROLLUP
select  department_id 부서코드, sum(salary) 부서별총합 
from employees
where department_id is not null
group by department_id WITH ROLLUP
HAVING sum(salary) >=50000
order by 2 desc;

-- 부서별 직종코드별 ROLLUP
select  department_id 부서코드, JOB_ID 직종코드, sum(salary) 부서별직종별총합 
from employees
where department_id is not null
group by department_id, JOB_ID WITH ROLLUP;


